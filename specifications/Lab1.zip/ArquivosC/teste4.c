#include <stdio.h>

int main(void)
{
	int i;
	i=1234;
	
	printf("Numero: %d\n",i);		
	return i+2;
	
}