#include <stdio.h>

int main(void)
{
	int i;
	i=2047;  //2048 explique
	
	return i+i;		
}