#include <stdio.h>
#include <math.h>

int main(void)
{
	float f1,f2;
	f1=1.5;
	f2=2.5;
	
	return (int) (f1*f2);
}